package com.example.personalfinance;

public enum TransactionType {
    INCOME, EXPENSE
}
